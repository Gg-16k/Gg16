TRUST MARKET — FINAL ONE-UPLOAD BUILD

This build is designed as a polished, mobile-first marketplace and ETCARE storefront.

Key updates:
- Uses the supplied modern home + car image as the main hero visual.
- Adds a clearly separated ETCARE Business Opportunity section.
- Business Package uses the company CBE destination; the account number is intentionally not stored in the public website files.
- Individual ETCARE product purchases remain separate and can be made without a package.
- Product cards prioritize useful product benefits, price, quantity, Buy Now and How to Use.
- CBE product payment: account number is intentionally not stored in the public website files.
- Telebirr product payment: account number is intentionally not stored in the public website files.
- Telegram verification: @Gg16A.
- WhatsApp/Call: 0923493781.
- No fake reviews are seeded.
- Never request PIN, password or OTP.

Important static-site limitation:
Payment is manual: the customer pays using the displayed account/service, keeps the receipt, then sends order details for verification. The current static build does not upload receipt images to a server or automatically verify payments.

Deploy: upload this ZIP once to the existing Netlify site using Netlify Drop.
